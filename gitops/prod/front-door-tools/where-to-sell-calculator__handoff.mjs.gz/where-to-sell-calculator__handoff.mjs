// Carry the item you just compared into the channel's own calculator.
//
// This page answers "which channel?" and stops there. The follow-up question —
// "so what does a promoted listing / free shipping / a return actually do to
// that number on eBay?" — is answered by a separate calculator in this
// portfolio with twenty-odd scenarios in it. Until now the only way through was
// to retype the item: price, postage, what you paid, packaging, everything.
// Most people do not, so the deep tool goes unused and the comparison ends at a
// ranking nobody acts on.
//
// So each channel that has a dedicated calculator *and* can accept inputs from
// a link gets a "continue with these numbers" link, built from what is on
// screen. Nothing is uploaded: this is the same in-page URL mechanism the
// "Copy share link" button already uses, and the values only ever travel
// inside the reader's own browser as they follow the link.
//
// The mapping is the fragile part. Each calculator named its inputs for its own
// niche — what this page calls `itemCost` is `costOfGoods` on eBay and
// `materialCost` on Etsy — and a name that does not match is *silently dropped*
// by the receiving decoder. The failure is a wrong number on arrival, not an
// error, which is exactly the bug `share.mjs` shipped once already (a link that
// dropped `quantity` and `targetMargin`, so the recipient computed a different
// profit than the sender saw). `handoff.test.mjs` therefore imports each
// target's own field list and asserts every name here is one it accepts.

/**
 * Channels with a deeper calculator that accepts inputs from a link.
 *
 * `fields` maps this page's shared-input id to the target's id. A channel
 * absent from this table simply gets no link — deliberately, since a link that
 * silently arrives with default numbers is worse than no link at all.
 */
export const HANDOFFS = [
  {
    channel: 'ebay',
    slug: 'ebay-fee-calculator',
    label: 'eBay fee & profit calculator',
    // What it adds: promoted listings, returns, Top Rated Plus, store
    // subscription, offers, international, and twenty more decisions.
    fields: {
      price: 'price',
      shippingCharged: 'shippingCharged',
      shippingCost: 'shippingCost',
      itemCost: 'costOfGoods',
      packagingCost: 'packagingCost',
      otherCost: 'otherCost',
    },
  },
  {
    channel: 'etsy',
    slug: 'etsy-profit-calculator',
    label: 'Etsy profit calculator',
    // Etsy has no separate packaging input; it belongs with materials, which
    // is what that field means there. Summed rather than dropped — see
    // `combine` below.
    fields: {
      price: 'price',
      shippingCharged: 'shippingCharged',
      shippingCost: 'shippingCost',
      itemCost: 'materialCost',
      otherCost: 'otherCost',
    },
    combine: { materialCost: ['itemCost', 'packagingCost'] },
  },
  {
    channel: 'amazon',
    slug: 'amazon-fba-calculator',
    label: 'Amazon FBA vs FBM calculator',
    // What it adds: the FBA-versus-FBM split this page cannot make (it prices
    // Amazon as one channel), plus size-tier fulfilment, storage by month,
    // inbound placement, returns, Low-Price FBA, coupons, Subscribe & Save,
    // Vine, and Seller Fulfilled Prime.
    //
    // `shippingCharged` has no home here and is deliberately dropped rather
    // than mapped: Amazon's referral fee is charged on the order total, but
    // this calculator takes the sale price and derives fulfilment from the
    // size tier instead of from what the buyer was charged for postage.
    // Folding postage into `salePrice` would inflate the referral fee and
    // print a worse number than the seller will actually see.
    fields: {
      price: 'salePrice',
      itemCost: 'costOfGoods',
      shippingCost: 'fbmShippingCost',
      packagingCost: 'packagingCost',
      otherCost: 'otherCost',
    },
  },
  {
    channel: 'own-store',
    slug: 'shopify-fee-calculator',
    label: 'Shopify fee & profit calculator',
    // What it adds: the question this page cannot ask, which is *which
    // processor*. An own store has no marketplace commission, so the whole
    // decision is Shopify Payments against PayPal or Stripe — and Shopify
    // charges an extra third-party transaction fee on top of the outside
    // processor's own rate, which generic fee pages leave out. Plus promos,
    // Shop Pay Installments, shipping labels, POS, refunds and chargebacks.
    //
    // `monthlyOrders` travels because the Shopify plan is a monthly fee, and
    // amortising it is the whole reason an own store can win on fees and lose
    // on cash. Arriving without it would price the plan against this page's
    // default order count rather than the seller's.
    fields: {
      price: 'price',
      shippingCharged: 'shippingCharged',
      shippingCost: 'shippingCost',
      itemCost: 'costOfGoods',
      packagingCost: 'packagingCost',
      otherCost: 'otherCost',
      monthlyOrders: 'monthlyOrders',
    },
  },
];

const bySlugSafe = (value) => /^[a-z0-9-]+$/.test(value);

/** The handoff for a channel id, or null if it has no prefillable calculator. */
export function handoffFor(channel) {
  return HANDOFFS.find((entry) => entry.channel === channel) ?? null;
}

/**
 * The values to hand over, as `{targetField: number}`.
 *
 * Only finite, non-negative numbers travel. A blank or nonsense input is left
 * out entirely so the target falls back to its own default, rather than
 * arriving as `NaN` or a silent zero that reads as a real answer.
 */
export function handoffValues(entry, shared = {}) {
  const out = {};
  if (!entry) return out;

  const clean = (value) => {
    // `Number('')` and `Number(null)` are both 0, so coercing first would turn
    // an untouched field into an explicit zero and override the target's own
    // default — the silent-wrong-number case this whole module is guarding.
    if (value === null || value === undefined) return null;
    if (typeof value === 'string' && value.trim() === '') return null;
    const number = Number(value);
    return Number.isFinite(number) && number >= 0 ? number : null;
  };

  for (const [source, target] of Object.entries(entry.fields)) {
    const value = clean(shared[source]);
    if (value !== null) out[target] = value;
  }

  // A target with fewer inputs than this page folds two of ours into one of
  // theirs, so the total cost survives the trip instead of being dropped.
  for (const [target, sources] of Object.entries(entry.combine ?? {})) {
    const parts = sources.map((source) => clean(shared[source])).filter((v) => v !== null);
    if (parts.length > 0) out[target] = parts.reduce((a, b) => a + b, 0);
  }

  return out;
}

/**
 * A relative link to the channel's calculator, carrying the item.
 *
 * Relative on purpose: the same href has to work under the project path prefix
 * GitHub Pages serves from, under a custom domain later, and from a local
 * `python3 -m http.server`. The values ride in the fragment, which browsers do
 * not send to any server.
 */
export function handoffUrl(channel, shared = {}) {
  const entry = handoffFor(channel);
  if (!entry || !bySlugSafe(entry.slug)) return null;

  const values = handoffValues(entry, shared);
  const params = new URLSearchParams();
  for (const field of Object.keys(values).sort()) params.set(field, String(values[field]));

  const query = params.toString();
  return `../${entry.slug}/${query ? `#${query}` : ''}`;
}

/**
 * Every available handoff for a comparison, best channel first.
 *
 * Ordered by the ranking the reader is looking at rather than by this table,
 * so the link they most likely want is the one they read first.
 */
export function handoffsForResults(results = [], shared = {}) {
  return results
    .slice()
    .sort((a, b) => (a.rank ?? 0) - (b.rank ?? 0))
    .map((result) => {
      const entry = handoffFor(result.id);
      if (!entry) return null;
      return {
        channel: result.id,
        label: entry.label,
        channelLabel: result.label ?? entry.channel,
        isBest: Boolean(result.isBest),
        href: handoffUrl(result.id, shared),
      };
    })
    .filter(Boolean);
}
