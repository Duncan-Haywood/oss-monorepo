// Records an anonymous, aggregate-only local usage count: the event name and
// the current day, kept in the visitor's own browser. It never stores the
// address, square footage, wages, or quoted price, and it never leaves the
// device — a contractor's pricing is exactly the sort of thing that must not
// be transmitted anywhere.

const STORAGE_KEY = 'asphalt-sealcoat-bid-usage';

function honorsBrowserSignal() {
  try {
    return globalThis.navigator?.doNotTrack === '1' || globalThis.navigator?.globalPrivacyControl === true;
  } catch {
    return false;
  }
}

export function recordUsage(storage = globalThis.localStorage, optedOut = false, event = 'bid_calculated') {
  if (optedOut || !storage || honorsBrowserSignal()) return;
  const today = new Date().toISOString().slice(0, 10);
  const current = JSON.parse(storage.getItem(STORAGE_KEY) || '{}');
  current[event] = (current[event] || 0) + 1;
  current.last_day = today;
  storage.setItem(STORAGE_KEY, JSON.stringify(current));
}
