const KEY = 'kdp-royalty-calculator-usage-v1';

function honorsBrowserSignal() {
  try {
    return (
      globalThis.navigator?.doNotTrack === '1' ||
      globalThis.window?.doNotTrack === '1' ||
      globalThis.navigator?.globalPrivacyControl === true
    );
  } catch {
    return false;
  }
}

export function recordUsage(event, optedOut = false, storage = globalThis.localStorage) {
  if (optedOut || !storage || readOptOut(storage) || honorsBrowserSignal()) return;
  try {
    const entries = JSON.parse(storage.getItem(KEY) || '{}');
    const day = new Date().toISOString().slice(0, 10);
    entries[`${event}:${day}`] = (entries[`${event}:${day}`] || 0) + 1;
    storage.setItem(KEY, JSON.stringify(entries));
  } catch {
    /* Calculator remains useful when storage is unavailable. */
  }
}

// The opt-out choice is kept in its own key, not in the counters:
// opting out *removes* the counters, so a flag stored inside them would
// be deleted by the very act it records. `recordUsage` above consults it
// directly as well as taking the caller's argument -- a stored preference
// that only one line of page wiring reads is one line away from being
// forgotten, which is the defect this change exists to fix.
export function readOptOut(storage = globalThis.localStorage) {
  try {
    return storage?.getItem(`${KEY}-opt-out`) === '1';
  } catch {
    // A blocked or full store must never be read as consent.
    return false;
  }
}

export function writeOptOut(storage = globalThis.localStorage, optedOut = false) {
  if (!storage) return;
  // Independent writes, counters first: sharing one try means a setItem
  // that throws on a full quota skips the delete entirely, and the
  // visitor gets neither half of what the control promised.
  if (optedOut) {
    try { storage.removeItem(KEY); } catch { /* storage is optional */ }
    try { storage.setItem(`${KEY}-opt-out`, '1'); } catch { /* storage is optional */ }
  } else {
    try { storage.removeItem(`${KEY}-opt-out`); } catch { /* storage is optional */ }
  }
}
