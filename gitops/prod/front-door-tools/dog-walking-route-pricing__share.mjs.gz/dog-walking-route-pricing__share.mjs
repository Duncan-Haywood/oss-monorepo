// A dog walker re-types the same visit assumptions — drive minutes, mileage
// rate, target hourly rate, overnight on-call hours — for every route they
// price. This module keeps that one-visit form: restored in the visitor's
// own browser between sessions, and carried into a link they can send
// themselves or a co-walker covering a route.
//
// Deliberately out of scope: the client list in the "Your route this month"
// table. That table's own copy promises client names and per-client prices
// are never saved anywhere, and this module must not quietly break that
// promise — so it only ever touches the visit fields below.
//
// Nothing here is transmitted. `localStorage` is the visitor's own disk, and
// the link is only ever built in their browser and copied by them. The visit
// travels in the URL *fragment* (`#...`), never the query string: a fragment
// is not sent in the request line a server logs, nor in a `Referer` header a
// later click would carry, so a shared visit stays off the machines it
// passes through on the way to the recipient.
//
// The field list is imported from `calc.mjs`'s `DEFAULTS` rather than
// restated here, so a visit field added to the arithmetic is shareable and
// restorable the moment it exists.

import { DEFAULTS } from './calc.mjs';

export const FIELD_IDS = Object.keys(DEFAULTS);

function usableNumber(value) {
  if (value === '' || value === null || value === undefined) return null;
  const result = Number(value);
  return Number.isFinite(result) && result >= 0 ? result : null;
}

export function encodeInputs(input) {
  const params = new URLSearchParams();
  for (const id of FIELD_IDS) {
    const value = usableNumber(input?.[id]);
    if (value !== null) params.set(id, String(value));
  }
  return params.toString();
}

export function decodeInputs(source) {
  const params = new URLSearchParams(String(source || '').replace(/^[?#]/, ''));
  const result = {};
  for (const id of FIELD_IDS) {
    if (!params.has(id)) continue;
    const value = usableNumber(params.get(id));
    if (value !== null) result[id] = value;
  }
  return result;
}
