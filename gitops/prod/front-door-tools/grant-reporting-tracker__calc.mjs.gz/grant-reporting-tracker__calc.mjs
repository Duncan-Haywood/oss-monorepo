export function parseDate(value) {
  const date = new Date(`${value}T00:00:00Z`);
  return Number.isNaN(date.getTime()) ? null : date;
}

// The visitor's own calendar date, not UTC's. `new Date().toISOString()`
// reads the UTC date, which is a different day from the visitor's local date
// for several hours every day everywhere except right on the meridian — ahead
// of local for negative UTC offsets in the evening, behind it for positive
// offsets overnight. `reviewGrant` and `sampleGrants` call this only when the
// page omits `today` (the only way either is ever actually invoked, since
// index.html never passes one), so that mismatch reached every visitor: a
// report due today could show "Overdue" a day early, or "On track" a day
// past what a filed-late letter says, depending only on the visitor's clock.
function localToday() {
  const now = new Date();
  return [
    now.getFullYear(),
    String(now.getMonth() + 1).padStart(2, '0'),
    String(now.getDate()).padStart(2, '0'),
  ].join('-');
}

// Month arithmetic in UTC, clamping to the last day of a shorter target month
// so 31 January plus one month is 28 February rather than 3 March. Accepts a
// negative shift, which `sampleGrants` needs to work backwards from a report
// date to the award date that produces it.
function shiftMonths(value, months) {
  const date = parseDate(value);
  if (!date) return null;
  const day = date.getUTCDate();
  date.setUTCDate(1);
  date.setUTCMonth(date.getUTCMonth() + Math.trunc(months));
  const lastDay = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 0)).getUTCDate();
  date.setUTCDate(Math.min(day, lastDay));
  return date.toISOString().slice(0, 10);
}

export function addMonths(value, months) {
  if (!Number.isFinite(months) || months < 1) return null;
  return shiftMonths(value, Math.floor(months));
}

/**
 * Three awards that demonstrate every status the queue can show.
 *
 * The dates are derived from `today` rather than written down, because a
 * hard-coded sample decays: a fixture dated 2026-03-15 reads as one more
 * overdue row a year later, and a first-time visitor cannot tell the example
 * from a bug. Working backwards from the report date means the sample shows an
 * overdue award, one due inside the month, and one on track, whenever it runs.
 *
 * Clamping in `shiftMonths` can move a derived report date by a day or two when
 * the month lengths differ. The offsets below are far enough from the 0 and 30
 * day status boundaries that the drift cannot change which status each row
 * lands in.
 */
export function sampleGrants(today = localToday()) {
  const awardDateFor = (reportInDays, intervalMonths) => {
    const base = parseDate(today);
    if (!base) return null;
    const report = new Date(base.getTime() + reportInDays * 86400000).toISOString().slice(0, 10);
    return shiftMonths(report, -intervalMonths);
  };
  return [
    { name: 'Community food program', funder: 'Local foundation', awardDate: awardDateFor(-21, 6), intervalMonths: 6, awardAmount: 24000, spentAmount: 8500 },
    { name: 'After-school literacy', funder: 'State education agency', awardDate: awardDateFor(14, 12), intervalMonths: 12, awardAmount: 48000, spentAmount: 31200 },
    { name: 'Winter shelter capital', funder: 'Regional health trust', awardDate: awardDateFor(96, 3), intervalMonths: 3, awardAmount: 15000, spentAmount: 15000 },
  ];
}

export function reviewGrant(grant, today = localToday()) {
  const nextReport = addMonths(grant.awardDate, Number(grant.intervalMonths));
  const days = nextReport ? Math.ceil((parseDate(nextReport) - parseDate(today)) / 86400000) : null;
  const restrictedBalance = Number(grant.awardAmount) - Number(grant.spentAmount);
  return {
    ...grant,
    nextReport,
    daysUntilReport: days,
    restrictedBalance,
    status: days === null ? 'Check inputs' : days < 0 ? 'Overdue' : days <= 30 ? 'Due soon' : 'On track',
  };
}

export function reviewAll(grants, today) {
  return grants.map((grant) => reviewGrant(grant, today)).sort((a, b) => (a.daysUntilReport ?? Infinity) - (b.daysUntilReport ?? Infinity));
}

// Every field the queue reads, not just the ones the table renders. A CSV
// exported to a board member, a co-signer, or a funder's file is often the
// only copy of an award that leaves this browser -- so a recipient with only
// the five displayed columns can see that a report is "Overdue" but cannot
// check *why* (no awardDate or intervalMonths to recompute nextReport from),
// cannot tell an approximate deadline from an urgent one (status buckets
// "Due soon" into one label whether it is due tomorrow or in three weeks,
// with no daysUntilReport), and cannot verify restrictedBalance without the
// awardAmount and spentAmount it is derived from. Dropping any of those from
// the export is the same defect `where-to-sell-calculator` shipped by
// hand-keeping an allowlist beside the form instead of deriving it: a field
// the page collects and computes quietly missing from the copy a second
// person reads.
export function toCsv(rows) {
  const fields = [
    'name', 'funder', 'awardDate', 'intervalMonths', 'nextReport',
    'daysUntilReport', 'status', 'awardAmount', 'spentAmount', 'restrictedBalance',
  ];
  const quote = (value) => `"${String(value ?? '').replaceAll('"', '""')}"`;
  return [fields.join(','), ...rows.map((row) => fields.map((field) => quote(row[field])).join(','))].join('\n');
}

// Saved awards come back from localStorage, which is user-writable and can be
// left damaged by an interrupted write or an older version of this page. A
// single null or string row used to reach reviewGrant and throw on
// `grant.awardDate`, blanking the whole queue — so drop anything that is not an
// object rather than trusting the parsed shape.
export function loadGrants(value) {
  if (!value) return [];
  try {
    const grants = JSON.parse(value);
    return Array.isArray(grants) ? grants.filter((grant) => grant && typeof grant === 'object') : [];
  } catch {
    return [];
  }
}
